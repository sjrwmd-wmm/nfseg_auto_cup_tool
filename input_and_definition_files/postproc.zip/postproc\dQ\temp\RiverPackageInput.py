#!/usr/bin/python
"""
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                              
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                             
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                  
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                           
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN                               
THE SOFTWARE.                                                                                           
                                                                                                        
Please report any errors to Trey Grubbs at the Suwannee River Water Management District (jwg@srwmd.org).

Change log: 2015-07-27    jwg    change method, parse_input_record_free_format,
                                 to extract Doug Durden's reach identifier from
                                 field index 8 (note that the fixed-format
                                 counterpart to this method, parse_input_record
                                 was not changed, so this should be updated at
                                 some point to maintain consistency.
"""

import shelve
import os
import sys

class RiverPackageInput:
    """ class for reading, storing, and modifying MODFLOW River Package input files. """
    
    def __init__(self, input_file_name, stress_period_data_line0, fixed_or_free):
        """ Open the River Package Input file, parse records in the stress-period data
            block, which begins on the line number indicated by init argument,
            stress_period_data_line0.
        """
        f = open(input_file_name, 'r')
        lines = f.readlines()
        f.close()
        # initialize a dictionary to contain stage, cond, rbot data for a given
        # record (river reach)
        self.reach_dict = {}
        # initialize a dictionary to contain a list of river-reach id's for
        # each model grid cell that has at least one River Package record/reach
        self.reach_ids_from_cell_address = {}
        # initialize a dictionary containing a list of unique river-reach id's
        #   for each '2-dimensional' GIS identifier (bc_2d_reach_id in method,
        #   assign_record_data
        self.reach_ids_from_2d_ids = {}
        
        self.reach_ids = []
        self.fixed_or_free = fixed_or_free.lower()
        if self.fixed_or_free != 'free':
            raise Exception('program needs to be revised to read fixed format')
        self.parse_input(lines[stress_period_data_line0 - 1:])
            
    def parse_input(self, stress_period_records):
        record_count = 0
        for record in stress_period_records:
            record_count += 1
            if self.fixed_or_free == 'fixed':
                record_data = self.parse_input_record(record)
            else:
                record_data = self.parse_input_record_free_format(record)
            temp_data = list(record_data)
            temp_data.append(record_count)
            record_data = tuple(temp_data)
            self.assign_record_data(record_data)
    
    def parse_input_record(self, record):
        """ Parse a stress-period record from the River Package input file. Please
            note that this method expects one 'auxiliary' variable to be present,
            a reach id (in columns 61-70) - unique identifier for this record
            """
        record_data = []
        start_index = 0
        for i in range(0,7):
            start_index = i*10
            end_index = start_index + 10
            field_value = record[start_index:end_index]
            if i in [0, 1, 2]:
                field_value = int(field_value)
            elif i in [3, 4, 5]:
                field_value = float(field_value)
            record_data.append(field_value)
        return tuple(record_data)        
    
    def parse_input_record_free_format(self, record):
        """ Parse a stress-period record from the River Package input file. Please
            note that this method expects one 'auxiliary' variable to be present
            in the field following the rbot field. This is the unique identifier
            for this record.
        """
        record_data = []
        record_list = record.rstrip().split()
        len_record_list = len(record_list)
        field_indices_to_parse = [0,1,2,3,4,5,6,8]
        for index in field_indices_to_parse:
            if index in (0,1,2,6,8):
                field_value = int(record_list[index])
            else:
                field_value = float(record_list[index])
            record_data.append(field_value)
        return tuple(record_data)

    def assign_record_data(self, record_data):
        """ Assign data from a River Package stress-period data record to a
            dictionary.
        """
        layer, row, column, stage, cond, rbot, bc_reach_id, bc_2d_reach_id, record_number = record_data
        grid_cell_address = (layer, row, column)
        if bc_reach_id in self.reach_ids:
            raise ValueError, 'reach-id %s has already been parsed. Please assign unique reach id to each River Package record' % (reach_id)
        else:
            self.reach_ids.append(bc_reach_id)
            self.reach_dict[(bc_reach_id, 'stage')] = stage
            self.reach_dict[(bc_reach_id, 'cond')] = cond
            self.reach_dict[(bc_reach_id, 'rbot')] = rbot
            self.reach_dict[(bc_reach_id, 'bc_2d_reach_id')] = bc_2d_reach_id
            self.reach_dict[(bc_reach_id, 'record_number')] = record_number

            if self.reach_ids_from_cell_address.has_key(grid_cell_address):
                self.reach_ids_from_cell_address[grid_cell_address].append(bc_reach_id)
            else:
                self.reach_ids_from_cell_address[grid_cell_address] = [bc_reach_id]

            if self.reach_ids_from_2d_ids.has_key(bc_2d_reach_id):
                self.reach_ids_from_2d_ids[bc_2d_reach_id].append(bc_reach_id)
            else:
                self.reach_ids_from_2d_ids[bc_2d_reach_id] = [bc_reach_id]

    def calc_river_flux_by_reach_id(self, reach_id, gw_head):
        """ Calculate a River Package flux. """
        stage = self.reach_dict[(reach_id, 'stage')]
        cond = self.reach_dict[(reach_id, 'cond')]
        rbot = self.reach_dict[(reach_id, 'rbot')]
        if gw_head > rbot:
            if gw_head > stage:
                river_flux = (stage - gw_head)*cond
            else:
                river_flux = -1.*(stage - gw_head)*cond
        else:
            river_flux = (stage - rbot)*cond
        self.reach_dict[(reach_id, 'flux_sim')] = river_flux

    def calc_river_flux_by_cell_address(self, grid_cell_address, gw_head):
        """ Calculate total River Package flux for a give grid-cell address.
        
            cell_address is a (layer, row, column) tuple
        """
        total_river_flux = 0.
        if self.reach_ids_from_cell_address.has_key(grid_cell_address):
            reach_ids = self.reach_ids_from_cell_address[grid_cell_address]
        else:
            reach_ids = []
        for reach_id in reach_ids:
            stage = self.reach_dict[(reach_id, 'stage')]
            cond = self.reach_dict[(reach_id, 'cond')]
            rbot = self.reach_dict[(reach_id, 'rbot')]
            if gw_head > rbot:
                if gw_head > stage:
                    river_flux = (stage - gw_head)*cond
                else:
                    river_flux = -1.*(stage - gw_head)*cond
            else:
                river_flux = (stage - rbot)*cond
            total_river_flux += river_flux
        return total_river_flux

def main():
     river_package_input_file_name = sys.argv[1]
     #river_package_input_file_name = 'temp.asc'
     shelf_file_name = river_package_input_file_name + '.shelf'
     if os.path.exists(os.path.join(os.getcwd(),shelf_file_name)):
         os.remove(os.path.join(os.getcwd(),shelf_file_name))
     book = shelve.open(shelf_file_name)
     a = RiverPackageInput(river_package_input_file_name, 1, 'free')
     book['reach_ids_from_cell_address'] = a.reach_ids_from_cell_address
     book['reach_dict'] = a.reach_dict
     book['reach_ids'] = a.reach_ids
     book['reach_ids_from_2d_ids'] = a.reach_ids_from_2d_ids
     book.close()
     print 'All done!'

main()
