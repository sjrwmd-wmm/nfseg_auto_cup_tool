#!/usr/bin/python
"""

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                              
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                             
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                  
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                           
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN                               
THE SOFTWARE.                                                                                           
                                                                                                        
Please report any errors to Trey Grubbs at the Suwannee River Water Management District (jwg@srwmd.org).

change log:

   * 2017-09-06 jwg update to handle Tim D's modification to append gaged-reach id to end of Drain Package
                    input file records. The program now gets the 2d id from the _next_to_the last
                    field in the input file, nfseg.drn.sp1.

"""
import os
import shelve

# read stress period 2 'data records' from  Drain Package input file
f = open('nfseg.drn.sp1','r')
lines = [line.strip().split() for line in f.readlines()]
f.close()

# output the data from the first record as a check
print_string = "data from first input record of Drain Package input file data block: \n    {0}\n".format(lines[0])
print()

# extract 2d ids?
ids_2d = [int(x[-2]) for x in lines]

# output the data from the last 20 elements as a check
print("last 20 2d ids: \n    {0}\n".format(ids_2d[-20:]))

# print the total number of records read (and id's extracted) as a check
print("The total number of records read (and id's extracted is: \n    {0}\n".format(len(ids_2d)))

# open lookup 'shelf file' with RIV and GHB data and extract dicts with reach data
book = shelve.open('lookup_bc_reach_ids.shelf')
reach_ids = book['reach_ids']
reach_ids_from_2d_ids = book['reach_ids_from_2d_ids']

# add DRN data to dicts
reach_ids[('drn', 1)] = ids_2d
reach_ids[('drn', 2)] = ids_2d
book['reach_ids'] = reach_ids

# print the keys in the shelf file as a check
print("The file, lookup_bc_reach_ids.shelf, contains the following keys: \n    {0}\n".format(book.keys()))

# print the last 10 entries of the stress period 1 DRAIN package reach_ids dict as a check
print("The last 10 entries of the stress period 1 DRAIN package reach_ids dict are as follows: \n    {0}\n".format(book['reach_ids'][('drn', 1)][-10:]))

# close the shelf file
book.close()

print("Drain Package data have been added to file, lookup_bc_reach_ids.shelf.\n\nAll done!")

book.close()



