#!/usr/bin/python
"""

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR                              
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,                                
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE                             
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER                                  
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,                           
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN                               
THE SOFTWARE.                                                                                           
                                                                                                        
Please report any errors to Trey Grubbs at the Suwannee River Water Management District (jwg@srwmd.org).

"""
import os
import shelve

def extract_shelve_object(input_shelve_file_name, input_key):
    """ Open a 'shelve' file, then extract and return the object
        associated with the supplied key.
    """
    book = shelve.open(input_shelve_file_name)
    if book.has_key(input_key):
        object_to_return = book[input_key]
    else:
        book.close()
        raise Exception, "{0} did not have key, {1}".format(input_shelve_file_name, input_key)
    book.close()
    return(object_to_return)

def open_shelve_file_for_output(shelve_file_name):
    """ Open a 'shelve' file for output. """
    if os.path.exists(os.path.join(os.getcwd(),shelve_file_name)):
        os.remove(os.path.join(os.getcwd(),shelve_file_name))
    book = shelve.open(shelve_file_name)
    return(book)

def main():
    model_name = 'nfseg'
    bc_types = ['riv','ghb']
    stress_periods = [1,2]
    bc_reach_id_dict = {}
    reach_ids_from_2d_ids = {}

    output_shelf_fileName = 'lookup_bc_reach_ids.shelf'
    if os.path.exists(os.path.join(os.getcwd(),output_shelf_fileName)):
	os.remove(os.path.join(os.getcwd(),output_shelf_fileName))
    out_book = open_shelve_file_for_output('lookup_bc_reach_ids.shelf')

    for bc_type in bc_types:
        for stress_period in stress_periods:
            input_shelve_file_name = "{0}.{1}.sp{2}.shelf".format(model_name,bc_type,stress_period)
            reach_ids = extract_shelve_object(input_shelve_file_name, 'reach_ids')
            bc_reach_id_dict[(bc_type, stress_period)] = reach_ids
            if bc_type == 'riv':
		temp_reach_ids_dict = extract_shelve_object(input_shelve_file_name, 'reach_ids_from_2d_ids')
                reach_ids_from_2d_ids[(bc_type, stress_period)] = temp_reach_ids_dict

    out_book['reach_ids'] = bc_reach_id_dict
    out_book['reach_ids_from_2d_ids'] = reach_ids_from_2d_ids
    out_book.close()
    print("All Done!")

main()

            
            
    